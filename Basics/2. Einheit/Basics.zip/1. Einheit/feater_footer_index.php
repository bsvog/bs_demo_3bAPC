<?php
include 'header.php';
?>

<div>Woow</div>

<?php
include 'footer.php';
?>