<?php

function erstelleSchuelerListe(){
    return [
        ['name' => 'Max Musterfrau', 'alter' => 16, 'klasse' => '3bAPC'],
        ['name' => 'Lisa Laufer', 'alter' => 21, 'klasse' => '2bAPC'],
        ['name' => 'Gustav Bauernfeind', 'alter' => 25, 'klasse' => '1cITS']
    ]; 
}

function zeigeSchuelerTabelle($schuelerListe){
    $html = '<table border="1" style=width:100%; border-collapse: collapse;">';
    $html .= '<tr><th>Name</th><th>Alter</th><th>Klasse</th></tr>';

    foreach ($schuelerListe as $schueler) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($schueler['name']) . '</td>';
        $html .= '<td>' . htmlspecialchars($schueler['alter']) . '</td>';
        $html .= '<td>' . htmlspecialchars($schueler['klasse']) . '</td>';
        $html .= '</tr>';
    }
    $html .= '</table>';
    return $html;
}